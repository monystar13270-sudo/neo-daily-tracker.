package com.daily.point.utils

import android.content.Context
import androidx.datastore.preferences.core.edit
import com.daily.point.data.PrefKeys
import com.daily.point.data.prefsDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object ThemeUtils {
    fun isDark(context: Context): Boolean = runBlocking {
        val prefs = context.prefsDataStore.data.first()
        val theme = prefs[PrefKeys.THEME] ?: "dark"
        theme == "dark"
    }
    fun setTheme(context: Context, theme: String) = runBlocking {
        context.prefsDataStore.edit { it[PrefKeys.THEME] = theme }
    }
}
