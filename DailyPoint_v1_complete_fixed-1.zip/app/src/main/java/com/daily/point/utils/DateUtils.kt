package com.daily.point.utils

import java.time.LocalDate
import java.time.format.DateTimeFormatter

object DateUtils{private val f=DateTimeFormatter.ofPattern("yyyy-MM-dd"); fun today():String=LocalDate.now().format(f)}
