package com.daily.point.ui

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.navigation.compose.*
import com.daily.point.ui.screens.*

@Composable
fun AppScaffold() {
    val nav = rememberNavController()
    Scaffold(
        bottomBar = {
            NavigationBar {
                val route = nav.currentBackStackEntryAsState().value?.destination?.route
                NavigationBarItem(selected = route=="today", onClick = { nav.navigate("today") }, label={Text("Aujourd’hui")}, icon={})
                NavigationBarItem(selected = route=="history", onClick = { nav.navigate("history") }, label={Text("Historique")}, icon={})
                NavigationBarItem(selected = route=="stats", onClick = { nav.navigate("stats") }, label={Text("Stats")}, icon={})
                NavigationBarItem(selected = route=="settings", onClick = { nav.navigate("settings") }, label={Text("Paramètres")}, icon={})
            }
        }
    ) { _ ->
        NavHost(navController = nav, startDestination = "today", modifier = Modifier) {
            composable("today") { TodayScreen() }
            composable("history") { HistoryScreen() }
            composable("stats") { StatsScreen() }
            composable("settings") { SettingsScreen() }
        }
    }
}
