package com.daily.point.utils

import android.content.Context
import android.net.Uri
import java.io.File
import java.util.UUID

object MediaStoreUtils {
    fun saveToInternal(context: Context, uri: Uri, folder: String): String {
        val dir = File(context.filesDir, folder)
        dir.mkdirs()
        val out = File(dir, UUID.randomUUID().toString())
        context.contentResolver.openInputStream(uri).use { input ->
            out.outputStream().use { output -> input?.copyTo(output) }
        }
        return out.absolutePath
    }
}
