package com.daily.point.data

import android.content.Context
import androidx.room.*

@Database(entities = [DailyEntry::class], version = 1)
abstract class AppDatabase : RoomDatabase() {
    abstract fun dao(): DailyEntryDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null
        fun get(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "daily_point.db")
                    .build().also { INSTANCE = it }
            }
    }
}
