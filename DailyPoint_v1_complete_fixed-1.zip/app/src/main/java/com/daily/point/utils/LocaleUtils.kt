package com.daily.point.utils

import android.content.Context
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import androidx.datastore.preferences.core.edit
import com.daily.point.data.PrefKeys
import com.daily.point.data.prefsDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking

object LocaleUtils {
    fun setLocale(context: Context, code: String) {
        val locales = LocaleListCompat.forLanguageTags(code)
        AppCompatDelegate.setApplicationLocales(locales)
        runBlocking { context.prefsDataStore.edit { it[PrefKeys.LANG] = code } }
    }

    fun applySavedLocale(context: Context) {
        runBlocking {
            val prefs = context.prefsDataStore.data.first()
            val code = prefs[PrefKeys.LANG] ?: "fr"
            val locales = LocaleListCompat.forLanguageTags(code)
            AppCompatDelegate.setApplicationLocales(locales)
        }
    }
}
