package com.daily.point.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.daily.point.data.AppDatabase
import com.daily.point.data.DailyEntry
import com.daily.point.utils.JsonUtils
import kotlinx.coroutines.launch

@Composable
fun HistoryScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).dao() }
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<DailyEntry>>(emptyList()) }

    LaunchedEffect(Unit) { scope.launch { list = dao.all() } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Historique", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(10.dp))
        LazyColumn {
            items(list) { e ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(12.dp)) {
                        Text(e.date, style = MaterialTheme.typography.titleMedium)
                        Text("Humeur: ${e.humeur ?: "-"} • Énergie: ${e.energie ?: "-"} • Stress: ${e.stress ?: "-"}")
                        if (e.temperature != null) Text("Temp: ${e.temperature}°C • Pluie: ${e.pluieMm ?: 0.0}mm • Vent: ${e.ventKmh ?: 0.0}km/h")
                        Text("Photos: ${JsonUtils.fromJsonList(e.photosJson).size} • Audios: ${JsonUtils.fromJsonList(e.audiosJson).size}")
                    }
                }
            }
        }
    }
}
