package com.daily.point.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.work.*
import com.daily.point.data.PrefKeys
import com.daily.point.data.prefsDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.time.LocalDate
import java.time.LocalTime
import java.util.concurrent.TimeUnit

object NotificationUtils {
    private const val CHANNEL_ID = "daily_point"
    private val KEY_LAST_FILLED = stringPreferencesKey("last_filled_date")

    fun ensureChannel(context: Context) {
        val mgr = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        mgr.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Daily Point", NotificationManager.IMPORTANCE_HIGH))
    }

    fun markFilled(context: Context, date: String) = runBlocking {
        context.prefsDataStore.edit { it[KEY_LAST_FILLED] = date }
    }

    private fun isFilledToday(context: Context): Boolean = runBlocking {
        val prefs = context.prefsDataStore.data.first()
        (prefs[KEY_LAST_FILLED] ?: "") == LocalDate.now().toString()
    }

    fun scheduleAll(context: Context) {
        ensureChannel(context)
        val work = PeriodicWorkRequestBuilder<EndOfDayWorker>(15, TimeUnit.MINUTES).build()
        WorkManager.getInstance(context).enqueueUniquePeriodicWork("dp_endofday", ExistingPeriodicWorkPolicy.UPDATE, work)
    }

    fun show(context: Context, title: String, text: String) {
        ensureChannel(context)
        val prefs = runBlocking { context.prefsDataStore.data.first() }
        val vibrate = prefs[PrefKeys.NOTIF_VIBRATE] ?: true
        val sound = prefs[PrefKeys.NOTIF_SOUND] ?: true
        val builder = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_today)
            .setContentTitle(title)
            .setContentText(text)
            .setPriority(NotificationCompat.PRIORITY_HIGH)

        NotificationManagerCompat.from(context).notify((System.currentTimeMillis()%100000).toInt(), builder.build())
    }

    class EndOfDayWorker(ctx: Context, params: WorkerParameters): Worker(ctx, params) {
        override fun doWork(): Result {
            val context = applicationContext
            val prefs = runBlocking { context.prefsDataStore.data.first() }
            val endH = prefs[PrefKeys.END_HOUR] ?: 21
            val endM = prefs[PrefKeys.END_MIN] ?: 0
            val interval = prefs[PrefKeys.NAG_INTERVAL] ?: 20
            val max = prefs[PrefKeys.NAG_MAX] ?: 6
            val enableNag = prefs[PrefKeys.ENABLE_NAG] ?: true
            val enableHoliday = prefs[PrefKeys.ENABLE_HOLIDAY] ?: true

            val now = LocalTime.now()
            val end = LocalTime.of(endH, endM)
            if (enableHoliday) {
                HolidayUtils.holidayName()?.let { show(context, "Daily Point", "Bonne fête : $it") }
            }
            if (!enableNag) return Result.success()
            if (now.isBefore(end)) return Result.success()
            if (!isFilledToday(context)) {
                show(context, "Daily Point", "Tu n’as pas rempli ta journée.")
            }
            return Result.success()
        }
    }
}
