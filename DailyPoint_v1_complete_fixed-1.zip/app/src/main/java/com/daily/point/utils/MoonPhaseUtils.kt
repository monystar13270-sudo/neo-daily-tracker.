package com.daily.point.utils

import java.time.LocalDate
import kotlin.math.floor

object MoonPhaseUtils {
    fun phaseName(date: LocalDate = LocalDate.now()): String {
        val days = date.toEpochDay()
        val synodic = 29.53058867
        val phase = (days % synodic) / synodic
        return when {
            phase < 0.03 || phase > 0.97 -> "Nouvelle lune"
            phase < 0.22 -> "Premier croissant"
            phase < 0.28 -> "Premier quartier"
            phase < 0.47 -> "Gibbeuse croissante"
            phase < 0.53 -> "Pleine lune"
            phase < 0.72 -> "Gibbeuse décroissante"
            phase < 0.78 -> "Dernier quartier"
            else -> "Dernier croissant"
        }
    }
}
