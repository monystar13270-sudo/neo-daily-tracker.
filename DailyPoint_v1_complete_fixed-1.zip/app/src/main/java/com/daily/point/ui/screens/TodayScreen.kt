package com.daily.point.ui.screens

import android.Manifest
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.daily.point.data.AppDatabase
import com.daily.point.data.DailyEntry
import com.daily.point.utils.*
import kotlinx.coroutines.launch
import java.time.LocalDate

@Composable
fun TodayScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).dao() }
    val scope = rememberCoroutineScope()
    val date = remember { DateUtils.today() }

    // sliders
    var tristesse by remember { mutableStateOf(5f) }
    var humeur by remember { mutableStateOf(5f) }
    var energie by remember { mutableStateOf(5f) }
    var fatigue by remember { mutableStateOf(5f) }
    var solitude by remember { mutableStateOf(5f) }
    var stress by remember { mutableStateOf(5f) }
    var anxiete by remember { mutableStateOf(5f) }
    var qualiteSommeil by remember { mutableStateOf(5f) }
    var productivite by remember { mutableStateOf(5f) }

    // texts
    var resume by remember { mutableStateOf("") }
    var meilleurMoment by remember { mutableStateOf("") }
    var pireMoment by remember { mutableStateOf("") }
    var noteLibre by remember { mutableStateOf("") }
    var parleAQui by remember { mutableStateOf("") }

    // durations minutes (simple)
    fun onlyDigits(s:String)=s.filter{it.isDigit()}
    var sportMin by remember { mutableStateOf("") }
    var lectureMin by remember { mutableStateOf("") }
    var jeuxMin by remember { mutableStateOf("") }
    var dehorsMin by remember { mutableStateOf("") }
    var dehorsAmisMin by remember { mutableStateOf("") }
    var ecranTelMin by remember { mutableStateOf("") }
    var ordinateurMin by remember { mutableStateOf("") }

    // br +/-
    var br by remember { mutableStateOf(0) }

    // times
    var reveil by remember { mutableStateOf("") }
    var coursDebut by remember { mutableStateOf("") }
    var coursFin by remember { mutableStateOf("") }

    // media saved internally
    var photos by remember { mutableStateOf(listOf<String>()) }
    var audios by remember { mutableStateOf(listOf<String>()) }

    val pickPhoto = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val path = MediaStoreUtils.saveToInternal(context, it, "photos")
            photos = photos + path
        }
    }
    val pickAudio = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val path = MediaStoreUtils.saveToInternal(context, it, "audios")
            audios = audios + path
        }
    }

    val scroll = rememberScrollState()
    val isVac = VacationUtils.isVacation(context, LocalDate.now())
    val isHol = HolidayUtils.isHoliday()

    Column(Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp)) {
        Text("Daily Point • $date", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(10.dp))

        SliderBlock("Tristesse", tristesse){tristesse=it}
        SliderBlock("Humeur", humeur){humeur=it}
        SliderBlock("Énergie", energie){energie=it}
        SliderBlock("Fatigue", fatigue){fatigue=it}
        SliderBlock("Solitude", solitude){solitude=it}
        SliderBlock("Stress", stress){stress=it}
        SliderBlock("Anxiété", anxiete){anxiete=it}
        SliderBlock("Qualité du sommeil", qualiteSommeil){qualiteSommeil=it}
        SliderBlock("Productivité", productivite){productivite=it}

        Spacer(Modifier.height(8.dp))
        TextFieldBlock("Résumé de la journée", resume){resume=it}
        TextFieldBlock("Meilleur moment", meilleurMoment){meilleurMoment=it}
        TextFieldBlock("Pire moment / difficulté", pireMoment){pireMoment=it}
        TextFieldBlock("À qui j’ai parlé aujourd’hui", parleAQui){parleAQui=it}
        TextFieldBlock("Note libre", noteLibre){noteLibre=it}

        Spacer(Modifier.height(8.dp))
        Text("Temps (minutes)", style = MaterialTheme.typography.titleMedium)
        Duration("Sport", sportMin){sportMin=onlyDigits(it)}
        Duration("Lecture", lectureMin){lectureMin=onlyDigits(it)}
        Duration("Jeux", jeuxMin){jeuxMin=onlyDigits(it)}
        Duration("Temps écran téléphone", ecranTelMin){ecranTelMin=onlyDigits(it)}
        Duration("Temps ordinateur", ordinateurMin){ordinateurMin=onlyDigits(it)}
        Duration("Temps dehors", dehorsMin){dehorsMin=onlyDigits(it)}
        Duration("Dehors avec amis", dehorsAmisMin){dehorsAmisMin=onlyDigits(it)}

        Spacer(Modifier.height(8.dp))
        Text("BR", style = MaterialTheme.typography.titleMedium)
        Row {
            Button(onClick={ if(br>0) br-- }){Text("-")}
            Spacer(Modifier.width(8.dp))
            OutlinedTextField(value=br.toString(), onValueChange={ br = it.filter{c->c.isDigit()}.toIntOrNull()?:0 }, label={Text("Nombre")}, modifier=Modifier.weight(1f))
            Spacer(Modifier.width(8.dp))
            Button(onClick={ br++ }){Text("+")}
        }

        Spacer(Modifier.height(8.dp))
        Text("Horaires", style = MaterialTheme.typography.titleMedium)
        OutlinedTextField(value=reveil, onValueChange={reveil=it}, label={Text("Réveil (HH:mm)")}, modifier=Modifier.fillMaxWidth())
        if(!isVac && !isHol){
            OutlinedTextField(value=coursDebut, onValueChange={coursDebut=it}, label={Text("Cours début (HH:mm)")}, modifier=Modifier.fillMaxWidth())
            OutlinedTextField(value=coursFin, onValueChange={coursFin=it}, label={Text("Cours fin (HH:mm)")}, modifier=Modifier.fillMaxWidth())
        } else {
            Text("Cours masqués (vacances ou jour férié).", style = MaterialTheme.typography.bodySmall)
        }

        Spacer(Modifier.height(8.dp))
        Text("Médias (dans l’app)", style = MaterialTheme.typography.titleMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick={ pickPhoto.launch("image/*") }){Text("Ajouter photo")}
            Button(onClick={ pickAudio.launch("audio/*") }){Text("Ajouter audio")}
        }
        Text("Photos: ${photos.size} • Audios: ${audios.size}")

        Spacer(Modifier.height(12.dp))
        Button(onClick={
            scope.launch {
                val w = WeatherService.fetch(context)
                val entry = DailyEntry(
                    date=date,
                    tristesse=tristesse.toInt(),
                    humeur=humeur.toInt(),
                    energie=energie.toInt(),
                    fatigue=fatigue.toInt(),
                    solitude=solitude.toInt(),
                    stress=stress.toInt(),
                    anxiete=anxiete.toInt(),
                    qualiteSommeil=qualiteSommeil.toInt(),
                    productivite=productivite.toInt(),
                    resume=resume.ifBlank{null},
                    meilleurMoment=meilleurMoment.ifBlank{null},
                    pireMoment=pireMoment.ifBlank{null},
                    noteLibre=noteLibre.ifBlank{null},
                    parleAQui=parleAQui.ifBlank{null},
                    sportMin=sportMin.toIntOrNull(),
                    lectureMin=lectureMin.toIntOrNull(),
                    jeuxMin=jeuxMin.toIntOrNull(),
                    dehorsMin=dehorsMin.toIntOrNull(),
                    dehorsAmisMin=dehorsAmisMin.toIntOrNull(),
                    ecranTelMin=ecranTelMin.toIntOrNull(),
                    ordinateurMin=ordinateurMin.toIntOrNull(),
                    brCount=br,
                    reveil=reveil.ifBlank{null},
                    coursDebut= if(!isVac && !isHol) coursDebut.ifBlank{null} else null,
                    coursFin= if(!isVac && !isHol) coursFin.ifBlank{null} else null,
                    ville=w.city,
                    latitude=w.lat,
                    longitude=w.lon,
                    temperature=w.temp,
                    pluieMm=w.rain,
                    ventKmh=w.wind,
                    humidite=w.humidity,
                    lunePhase=w.moon,
                    photosJson=JsonUtils.toJsonList(photos),
                    audiosJson=JsonUtils.toJsonList(audios)
                )
                dao.upsert(entry)
                NotificationUtils.markFilled(context, date)
            }
        }, modifier=Modifier.fillMaxWidth()){ Text("Enregistrer") }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable private fun SliderBlock(label:String, value:Float, on:(Float)->Unit){
    Text("$label : ${value.toInt()}"); Slider(value=value, onValueChange=on, valueRange=1f..10f, steps=8)
    Spacer(Modifier.height(6.dp))
}
@Composable private fun TextFieldBlock(label:String, value:String, on:(String)->Unit){
    OutlinedTextField(value=value, onValueChange=on, label={Text(label)}, modifier=Modifier.fillMaxWidth()); Spacer(Modifier.height(6.dp))
}
@Composable private fun Duration(label:String, value:String, on:(String)->Unit){
    OutlinedTextField(value=value, onValueChange=on, label={Text(label)}, modifier=Modifier.fillMaxWidth()); Spacer(Modifier.height(6.dp))
}
