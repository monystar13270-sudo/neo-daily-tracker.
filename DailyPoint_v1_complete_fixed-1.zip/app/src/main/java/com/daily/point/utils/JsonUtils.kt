package com.daily.point.utils

import kotlinx.serialization.encodeToString
import kotlinx.serialization.json.Json

object JsonUtils {
    val json = Json { ignoreUnknownKeys = true }
    fun toJsonList(list: List<String>): String = json.encodeToString(list)
    fun fromJsonList(s: String?): List<String> = try {
        if (s.isNullOrBlank()) emptyList() else json.decodeFromString(s)
    } catch (e: Exception) { emptyList() }
}
