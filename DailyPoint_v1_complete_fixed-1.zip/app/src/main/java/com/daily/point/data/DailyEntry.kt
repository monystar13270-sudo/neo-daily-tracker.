package com.daily.point.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class DailyEntry(
    @PrimaryKey val date: String,

    // Notes 1-10
    val tristesse: Int? = null,
    val humeur: Int? = null,
    val energie: Int? = null,
    val fatigue: Int? = null,
    val solitude: Int? = null,
    val stress: Int? = null,
    val anxiete: Int? = null,
    val qualiteSommeil: Int? = null,
    val productivite: Int? = null,

    // Textes
    val resume: String? = null,
    val meilleurMoment: String? = null,
    val pireMoment: String? = null,
    val noteLibre: String? = null,
    val parleAQui: String? = null,

    // Durées minutes
    val sportMin: Int? = null,
    val lectureMin: Int? = null,
    val jeuxMin: Int? = null,
    val dehorsMin: Int? = null,
    val dehorsAmisMin: Int? = null,
    val sommeilMin: Int? = null,
    val travailMin: Int? = null,
    val ecranTelMin: Int? = null,
    val ordinateurMin: Int? = null,
    val meditationMin: Int? = null,
    val musiqueMin: Int? = null,
    val menageMin: Int? = null,
    val deplacementMin: Int? = null,

    // Compteur
    val brCount: Int? = null,

    // Horaires
    val reveil: String? = null,
    val coursDebut: String? = null,
    val coursFin: String? = null,

    // Auto
    val ville: String? = null,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val temperature: Double? = null,
    val pluieMm: Double? = null,
    val ventKmh: Double? = null,
    val humidite: Double? = null,
    val lunePhase: String? = null,

    // Médias stockés en JSON (URIs internes)
    val photosJson: String? = null,
    val audiosJson: String? = null
)
