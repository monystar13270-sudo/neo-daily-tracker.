package com.daily.point.ui.theme

import androidx.compose.material3.*
import androidx.compose.runtime.Composable

@Composable
fun DailyPointTheme(darkTheme: Boolean, content: @Composable ()->Unit) {
    MaterialTheme(
        colorScheme = if (darkTheme) darkColorScheme() else lightColorScheme(),
        typography = Typography(),
        content = content
    )
}
