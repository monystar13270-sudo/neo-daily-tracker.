package com.daily.point.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore

val Context.prefsDataStore by preferencesDataStore(name = "daily_point_prefs")

object PrefKeys {
    val LANG = stringPreferencesKey("lang") // fr/en/es/ru
    val THEME = stringPreferencesKey("theme") // dark/light/system
    val END_HOUR = intPreferencesKey("end_hour")
    val END_MIN = intPreferencesKey("end_min")
    val NAG_INTERVAL = intPreferencesKey("nag_interval")
    val NAG_MAX = intPreferencesKey("nag_max")
    val ENABLE_NAG = booleanPreferencesKey("enable_nag")
    val HELLO_HOUR = intPreferencesKey("hello_hour")
    val HELLO_MIN = intPreferencesKey("hello_min")
    val ENABLE_HELLO = booleanPreferencesKey("enable_hello")
    val ENABLE_HOLIDAY = booleanPreferencesKey("enable_holiday")
    val NOTIF_STYLE = stringPreferencesKey("notif_style") // compact/big
    val NOTIF_VIBRATE = booleanPreferencesKey("notif_vibrate")
    val NOTIF_SOUND = booleanPreferencesKey("notif_sound")
}
