package com.daily.point.data

import androidx.room.*

@Dao
interface DailyEntryDao {
    @Query("SELECT * FROM DailyEntry ORDER BY date DESC")
    suspend fun all(): List<DailyEntry>

    @Query("SELECT * FROM DailyEntry WHERE date = :date LIMIT 1")
    suspend fun byDate(date: String): DailyEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entry: DailyEntry)
}
