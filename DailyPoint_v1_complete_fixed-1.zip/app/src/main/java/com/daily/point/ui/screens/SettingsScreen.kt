package com.daily.point.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import com.daily.point.data.PrefKeys
import com.daily.point.data.prefsDataStore
import com.daily.point.utils.LocaleUtils
import com.daily.point.utils.NotificationUtils
import com.daily.point.utils.ThemeUtils
import com.daily.point.utils.VacationUtils
import kotlinx.coroutines.launch

@Composable
fun SettingsScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Paramètres", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(12.dp))

        Text("Langue")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick={LocaleUtils.setLocale(context,"fr")}){Text("FR")}
            Button(onClick={LocaleUtils.setLocale(context,"en")}){Text("EN")}
            Button(onClick={LocaleUtils.setLocale(context,"es")}){Text("ES")}
            Button(onClick={LocaleUtils.setLocale(context,"ru")}){Text("RU")}
        }

        Spacer(Modifier.height(12.dp))
        Text("Thème")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick={ThemeUtils.setTheme(context,"dark")}){Text("Sombre")}
            Button(onClick={ThemeUtils.setTheme(context,"light")}){Text("Clair")}
            Button(onClick={ThemeUtils.setTheme(context,"system")}){Text("Auto")}
        }
        Text("Relance l'app après changement si besoin.")

        Spacer(Modifier.height(12.dp))
        Text("Notifications")
        Button(onClick={ NotificationUtils.scheduleAll(context) }){Text("Activer / mettre à jour")}
        Spacer(Modifier.height(6.dp))
        Text("Réglages rapides")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick={saveInt(context, PrefKeys.END_HOUR, 21)}){Text("Fin 21h")}
            Button(onClick={saveInt(context, PrefKeys.NAG_INTERVAL, 20)}){Text("Intervalle 20m")}
            Button(onClick={saveInt(context, PrefKeys.NAG_MAX, 6)}){Text("Max 6")}
        }

        Spacer(Modifier.height(12.dp))
        Text("Vacances")
        Text("Ajoute une période (format yyyy-MM-dd)")
        var start by remember { mutableStateOf("") }
        var end by remember { mutableStateOf("") }
        OutlinedTextField(value=start,onValueChange={start=it},label={Text("Début")},modifier=Modifier.fillMaxWidth())
        OutlinedTextField(value=end,onValueChange={end=it},label={Text("Fin")},modifier=Modifier.fillMaxWidth())
        Button(onClick={ VacationUtils.addRange(context,start,end); start=""; end="" }){Text("Ajouter")}
        Spacer(Modifier.height(8.dp))

        Text("Logo personnalisé")
        Text("Android ne permet pas de changer l’icône du lanceur directement. L’app proposera un raccourci avec ton image (comme une icône perso).")
    }
}

private fun saveInt(context: Context, key: androidx.datastore.preferences.core.Preferences.Key<Int>, value: Int){
    val scope = kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO)
    scope.launch { context.prefsDataStore.edit { it[key] = value } }
}
