package com.daily.point.utils

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringSetPreferencesKey
import com.daily.point.data.prefsDataStore
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import java.time.LocalDate

object VacationUtils {
    private val KEY = stringSetPreferencesKey("vacations") // store ranges "yyyy-MM-dd..yyyy-MM-dd"
    fun addRange(context: Context, start: String, end: String) = runBlocking {
        context.prefsDataStore.edit { prefs ->
            val set = (prefs[KEY] ?: emptySet()).toMutableSet()
            set.add("$start..$end")
            prefs[KEY] = set
        }
    }
    fun ranges(context: Context): Set<String> = runBlocking { context.prefsDataStore.data.first()[KEY] ?: emptySet() }

    fun isVacation(context: Context, date: LocalDate = LocalDate.now()): Boolean {
        val d = date.toString()
        return ranges(context).any { r ->
            val parts = r.split("..")
            if (parts.size!=2) false else d >= parts[0] && d <= parts[1]
        }
    }
}
