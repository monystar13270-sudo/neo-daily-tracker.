package com.daily.point.utils

import java.time.LocalDate

object HolidayUtils {
    // Basic FR fixed-date + some movable approximations (v1). Can be improved later.
    fun isHoliday(date: LocalDate = LocalDate.now()): Boolean {
        val m = date.monthValue
        val d = date.dayOfMonth
        // fixed French public holidays
        if (m==1 && d==1) return true
        if (m==5 && d in listOf(1,8)) return true
        if (m==7 && d==14) return true
        if (m==8 && d==15) return true
        if (m==11 && d in listOf(1,11)) return true
        if (m==12 && d in listOf(25)) return true
        return false
    }

    fun holidayName(date: LocalDate = LocalDate.now()): String? {
        val m=date.monthValue; val d=date.dayOfMonth
        return when {
            m==1 && d==1 -> "Nouvel an"
            m==5 && d==1 -> "Fête du travail"
            m==5 && d==8 -> "Victoire 1945"
            m==7 && d==14 -> "Fête nationale"
            m==8 && d==15 -> "Assomption"
            m==11 && d==1 -> "Toussaint"
            m==11 && d==11 -> "Armistice"
            m==12 && d==25 -> "Noël"
            else -> null
        }
    }
}
