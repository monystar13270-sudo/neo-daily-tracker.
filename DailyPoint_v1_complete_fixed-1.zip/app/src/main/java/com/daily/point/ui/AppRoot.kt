package com.daily.point.ui

import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.daily.point.ui.theme.DailyPointTheme
import com.daily.point.utils.LocaleUtils
import com.daily.point.utils.ThemeUtils

@Composable
fun AppRoot() {
    val context = LocalContext.current
    LaunchedEffect(Unit) { LocaleUtils.applySavedLocale(context) }
    val dark = ThemeUtils.isDark(context)
    DailyPointTheme(darkTheme = dark) { AppScaffold() }
}
