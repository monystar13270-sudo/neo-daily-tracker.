package com.daily.point.utils

import android.annotation.SuppressLint
import android.content.Context
import com.google.android.gms.location.LocationServices
import kotlinx.coroutines.suspendCancellableCoroutine
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import kotlin.coroutines.resume

data class WeatherBundle(
    val city: String?,
    val lat: Double?,
    val lon: Double?,
    val temp: Double?,
    val rain: Double?,
    val wind: Double?,
    val humidity: Double?,
    val moon: String?
)

object WeatherService {
    private val client = OkHttpClient()

    @SuppressLint("MissingPermission")
    suspend fun fetch(context: Context): WeatherBundle {
        val fused = LocationServices.getFusedLocationProviderClient(context)
        val loc = suspendCancellableCoroutine { cont ->
            fused.lastLocation.addOnSuccessListener { cont.resume(it) }
                .addOnFailureListener { cont.resume(null) }
        }
        val lat = loc?.latitude
        val lon = loc?.longitude
        if (lat==null || lon==null) return WeatherBundle(null,null,null,null,null,null,null, MoonPhaseUtils.phaseName())
        return try {
            val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,relative_humidity_2m,precipitation,wind_speed_10m"
            val req = Request.Builder().url(url).build()
            val resp = client.newCall(req).execute().body?.string().orEmpty()
            val json = JSONObject(resp).optJSONObject("current")
            WeatherBundle(
                city = null,
                lat = lat,
                lon = lon,
                temp = json?.optDouble("temperature_2m"),
                rain = json?.optDouble("precipitation"),
                wind = json?.optDouble("wind_speed_10m"),
                humidity = json?.optDouble("relative_humidity_2m"),
                moon = MoonPhaseUtils.phaseName()
            )
        } catch(e: Exception) {
            WeatherBundle(null,lat,lon,null,null,null,null, MoonPhaseUtils.phaseName())
        }
    }
}
