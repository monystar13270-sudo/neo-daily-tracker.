package com.daily.point.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.daily.point.data.AppDatabase
import com.daily.point.data.DailyEntry
import kotlinx.coroutines.launch

enum class ChartType { COURBE, BARRES, POINTS, AIRE, RADAR, HEATMAP }

@Composable
fun StatsScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.get(context).dao() }
    val scope = rememberCoroutineScope()
    var list by remember { mutableStateOf<List<DailyEntry>>(emptyList()) }
    var chartType by remember { mutableStateOf(ChartType.COURBE) }

    LaunchedEffect(Unit) { scope.launch { list = dao.all() } }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Stats", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(8.dp))

        Text("Type de graphique")
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick={chartType=ChartType.COURBE}){Text("Courbe")}
            Button(onClick={chartType=ChartType.BARRES}){Text("Barres")}
            Button(onClick={chartType=ChartType.RADAR}){Text("Radar")}
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick={chartType=ChartType.POINTS}){Text("Points")}
            Button(onClick={chartType=ChartType.AIRE}){Text("Aire")}
            Button(onClick={chartType=ChartType.HEATMAP}){Text("Heatmap")}
        }

        Spacer(Modifier.height(12.dp))
        val avgHumeur = list.mapNotNull { it.humeur }.average().takeIf{!it.isNaN()}
        val avgEnergie = list.mapNotNull { it.energie }.average().takeIf{!it.isNaN()}
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(12.dp)) {
                Text("Moyennes (jours remplis)")
                Text("Humeur: ${avgHumeur?.let{String.format("%.2f",it)} ?: "-"}")
                Text("Énergie: ${avgEnergie?.let{String.format("%.2f",it)} ?: "-"}")
                Text("Graphique sélectionné: ${chartType.name}")
                Text("V1: rendu graphique complet dans MPAndroidChart (en cours d'amélioration).")
            }
        }
    }
}
